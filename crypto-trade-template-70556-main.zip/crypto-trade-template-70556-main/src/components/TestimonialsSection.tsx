"use client";

import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card } from "./ui/card";

const testimonials = [
  {
    name: "Michael Chen",
    role: "CEO, TechStart Inc",
    image: "https://avatars.githubusercontent.com/u/1234567?v=4",
    content: "CreativeHub transformed our vision into a stunning digital product. Their attention to detail and creative approach exceeded all our expectations. Highly recommended!"
  },
  {
    name: "Sarah Johnson",
    role: "Marketing Director, StyleHub",
    image: "https://avatars.githubusercontent.com/u/2345678?v=4",
    content: "Working with CreativeHub was an absolute pleasure. They delivered a beautiful website that perfectly captures our brand identity and has significantly increased our conversions."
  },
  {
    name: "David Wilson",
    role: "Founder, FitLife App",
    image: "https://avatars.githubusercontent.com/u/3456789?v=4",
    content: "The team's expertise in mobile app development is outstanding. They created an intuitive, feature-rich app that our users love. Couldn't be happier with the results."
  },
  {
    name: "Emily Zhang",
    role: "Product Manager, InnovateCo",
    image: "https://avatars.githubusercontent.com/u/4567890?v=4",
    content: "CreativeHub's strategic approach to UX design helped us solve complex user experience challenges. Their work has been instrumental in our product's success."
  },
  {
    name: "James Rodriguez",
    role: "E-commerce Director",
    image: "https://avatars.githubusercontent.com/u/5678901?v=4",
    content: "They rebuilt our entire e-commerce platform and the results speak for themselves - 200% increase in sales in just 3 months. Professional, creative, and reliable."
  },
  {
    name: "Lisa Thompson",
    role: "Brand Manager, LuxuryGoods",
    image: "https://avatars.githubusercontent.com/u/6789012?v=4",
    content: "The branding and web design they created for us is absolutely stunning. CreativeHub truly understands how to translate brand values into beautiful digital experiences."
  }
];

const TestimonialsSection = () => {
  return (
    <section className="py-20 overflow-hidden bg-black">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-normal mb-4">Trusted by Leading Brands</h2>
          <p className="text-muted-foreground text-lg">
            Join hundreds of satisfied clients who chose CreativeHub
          </p>
        </motion.div>

        <div className="relative flex flex-col antialiased">
          <div className="relative flex overflow-hidden py-4">
            <div className="animate-marquee flex min-w-full shrink-0 items-stretch gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={`${index}-1`} className="w-[400px] shrink-0 bg-black/40 backdrop-blur-xl border-white/5 hover:border-white/10 transition-all duration-300 p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={testimonial.image} />
                      <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium text-white/90">{testimonial.name}</h4>
                      <p className="text-sm text-white/60">{testimonial.role}</p>
                    </div>
                  </div>
                  <p className="text-white/70 leading-relaxed">
                    {testimonial.content}
                  </p>
                </Card>
              ))}
            </div>
            <div className="animate-marquee flex min-w-full shrink-0 items-stretch gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={`${index}-2`} className="w-[400px] shrink-0 bg-black/40 backdrop-blur-xl border-white/5 hover:border-white/10 transition-all duration-300 p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={testimonial.image} />
                      <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium text-white/90">{testimonial.name}</h4>
                      <p className="text-sm text-white/60">{testimonial.role}</p>
                    </div>
                  </div>
                  <p className="text-white/70 leading-relaxed">
                    {testimonial.content}
                  </p>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;